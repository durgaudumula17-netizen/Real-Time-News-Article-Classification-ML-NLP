from django.shortcuts import render, HttpResponse
from .forms import UserRegistrationForm
from django.contrib import messages
from .models import UserRegistrationModel
from django.core.files.storage import FileSystemStorage
import os


import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import io
import base64

def get_image_base64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format='png')
    buf.seek(0)
    image_base64 = base64.b64encode(buf.read()).decode('utf-8')
    buf.close()
    return image_base64
from django.shortcuts import render
from django.conf import settings

# Create your views here.
def UserRegisterActions(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            print('Data is Valid')
            form.save()
            messages.success(request, 'You have been successfully registered')
            form = UserRegistrationForm()
            return render(request, 'UserRegistrations.html', {'form': form})
        else:
            messages.success(request, 'Email or Mobile Already Existed')
            print("Invalid form")
    else:
        form = UserRegistrationForm()
    return render(request, 'UserRegistrations.html', {'form': form})


def UserLoginCheck(request):
    if request.method == "POST":
        loginid = request.POST.get('loginname')
        pswd = request.POST.get('pswd')
        print("Login ID = ", loginid, ' Password = ', pswd)
        try:
            check = UserRegistrationModel.objects.get(loginid=loginid, password=pswd)
            status = check.status
            print('Status is = ', status)
            if status == "activated":
                request.session['id'] = check.id
                request.session['loggeduser'] = check.name
                request.session['loginid'] = loginid
                request.session['email'] = check.email
                print("User id At", check.id, status)
                return render(request, 'users/UserHome.html', {})
            else:
                messages.success(request, 'Your Account Not at activated')
                return render(request, 'UserLogin.html')
        except Exception as e:
            print('Exception is ', str(e))
            pass
        messages.success(request, 'Invalid Login id and password')
    return render(request, 'UserLogin.html', {})


def UserHome(request):
    return render(request, 'users/UserHome.html', {})


def DatasetView(request):
    path =  os.path.join(settings.MEDIA_ROOT, 'artical_balanced_dataset.csv')
    df = pd.read_csv(path)
    df = df.to_html
    return render(request, 'users/viewdataset.html', {'data': df})


path = os.path.join(settings.MEDIA_ROOT, 'artical_balanced_dataset.csv')
df = pd.read_csv(path)

# Drop rows where 'title' or 'category' is NaN
df = df.dropna(subset=['title', 'category'])

# Value counts of the category column
value_counts = df['category'].value_counts()

# Plotting the distribution (optional)
# value_counts.plot(kind='bar')
# plt.xlabel('Categories')
# plt.ylabel('Counts')
# plt.title('Value Counts of Your Column')
# plt.show()

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(df['title'], df['category'], test_size=0.2, random_state=42)
# Vectorize the titles using TF-IDF
tfidf_vectorizer = TfidfVectorizer(max_features=20000, ngram_range=(1,2))
X_train_tfidf = tfidf_vectorizer.fit_transform(X_train)
X_test_tfidf = tfidf_vectorizer.transform(X_test)

# Train a Logistic Regression classifier
nb_classifier = LogisticRegression(max_iter=1000, random_state=42)
nb_classifier.fit(X_train_tfidf, y_train)


def training(request):
    # Make predictions and evaluate
    predictions = nb_classifier.predict(X_test_tfidf)
    test_accuracy = accuracy_score(y_test, predictions)  # Calculate actual testing accuracy
    train_predictions = nb_classifier.predict(X_train_tfidf)
    train_accuracy = accuracy_score(y_train, train_predictions)
    print(f"Training Accuracy: {train_accuracy:.7f}")
    print(f"Testing Accuracy: {test_accuracy:.2f}")

    # Confusion matrices
    train_confusion_matrix = confusion_matrix(y_train, train_predictions).tolist()
    test_confusion_matrix = confusion_matrix(y_test, predictions).tolist()

    # Generate accuracy comparison image
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(['Training', 'Testing'], [train_accuracy * 100, test_accuracy * 100], color=['#4CAF50', '#2196F3'], width=0.6, edgecolor='black')
    ax.set_ylim(0, 100)
    ax.set_ylabel('Accuracy (%)')
    ax.set_title('Accuracy Comparison')
    ax.grid(axis='y', linestyle='--', alpha=0.4)
    for i, v in enumerate([train_accuracy * 100, test_accuracy * 100]):
        ax.text(i, v + 1, f"{v:.2f}%", ha='center', fontweight='bold')
    accuracy_comparison_image = get_image_base64(fig)
    plt.close(fig)

    # Generate heatmap (using test confusion matrix as heatmap)
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(test_confusion_matrix, annot=True, fmt='d', cmap='Blues', ax=ax)
    ax.set_title('Feature Correlation Heatmap')  # Changed to match template
    ax.set_xlabel('Predicted')
    ax.set_ylabel('Actual')
    heatmap_image = get_image_base64(fig)
    plt.close(fig)

    # For url_features_image, set to None for now
    url_features_image = None

    # Optional url analysis, not implemented
    url_param = None
    url_prediction = None
    url_confidence = None

    # Pass results to template
    return render(request, "users/training.html", {
        'train_accuracy': train_accuracy,
        'train_confusion_matrix': train_confusion_matrix,
        'test_confusion_matrix': test_confusion_matrix,
        'heatmap_image': heatmap_image,
        'accuracy_comparison_image': accuracy_comparison_image,
        'url_features_image': url_features_image,
        'url_param': url_param,
        'url_prediction': url_prediction,
        'url_confidence': url_confidence,
    })
import os
import easyocr
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render

# Initialize the OCR reader once
reader = easyocr.Reader(['en'], gpu=False) # gpu=False stops the warning you saw earlier

def prediction(request):
    output_label = None
    extracted_text = ""
    all_confidences = [] # List to store all label scores

    if request.method == 'POST':
        # 1. Input Handling (Image or Text)
        if 'image_file' in request.FILES:
            image_file = request.FILES['image_file']
            fs = FileSystemStorage()
            filename = fs.save(image_file.name, image_file)
            uploaded_file_path = fs.path(filename)
            result = reader.readtext(uploaded_file_path)
            extracted_text = " ".join([res[1] for res in result])
            if os.path.exists(uploaded_file_path): os.remove(uploaded_file_path)
        else:
            extracted_text = request.POST.get('tweets', '')

        # 2. Prediction Logic
        if extracted_text.strip():
            test_tfidf = tfidf_vectorizer.transform([extracted_text])
            
            # Get the raw probabilities for EVERY class
            probabilities = nb_classifier.predict_proba(test_tfidf)[0]

            # Category Mapping
            categories_map = {
                0: 'ARTS & CULTURE', 1: 'BUSINESS', 2: 'COMEDY', 3: 'CRIME',
                4: 'EDUCATION', 5: 'ENTERTAINMENT', 6: 'ENVIRONMENT',
                7: 'MEDIA', 8: 'POLITICS', 9: 'RELIGION', 10: 'SCIENCE',
                11: 'SPORTS', 12: 'TECH'
            }

            # Create a list of all confidences
            all_confidences = []
            for index, prob in enumerate(probabilities):
                all_confidences.append({
                    'name': categories_map.get(index, f"Unknown {index}"),
                    'score': round(prob * 100, 2)
                })

            # Sort the list so the highest confidence is at the top
            all_confidences = sorted(all_confidences, key=lambda x: x['score'], reverse=True)
            
            # Take the top three
            top_three = all_confidences[:3]
            
            # Calculate the sum of their original scores
            total_score = sum(item['score'] for item in top_three)
            
            # Normalize the scores to sum to 100%
            if total_score > 0:
                for item in top_three:
                    item['score'] = round((item['score'] / total_score) * 100, 2)
            else:
                # Fallback to equal if sum is 0
                for item in top_three:
                    item['score'] = round(100 / 3, 2)
            
            # Create a list of dicts for template
            main_classifications = [{'name': item['name'], 'score': item['score']} for item in top_three]
            
        return render(request, 'users/predictForm1.html', {
            'main_classifications': main_classifications, 
            'extracted_text': extracted_text,
            'all_confidences': top_three,
        })

    return render(request, 'users/predictForm1.html', {})
